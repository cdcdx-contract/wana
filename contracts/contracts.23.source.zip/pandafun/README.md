# About PandaFun
PandaFun is the first real-time strategy blockchain DApp game based on EOS in the world, which combines both features of Monopoly and avatars education.

All the important codes concerning game fairnress are fully open-source and on chain to ensure absolutely no cheating by developers. Equally important, there is NO PRE-SALE of tokens in any kind.

We appreciate your review on our code. Please kindly verify our deployment on pandafuncode should you have any question.

You can get more infomation from our website : http://pandafun.io

And

Whitepaper English edition: https://github.com/pandafunx/doc/raw/master/PandaFun%20Game%20Whitepaper%20ENGLISH.pdf

Whitepaper Chinese edition: https://github.com/pandafunx/doc/raw/master/PandaFun%20Game%20Whitepaper%20CHINESE.pdf

You are also highly welcomed to join our telegram group: https://t.me/pandafungame or contact us by email: pandafun.x@gmail.com