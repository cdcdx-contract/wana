 --- squeakr Project ---

 - How to Build -
   - run the command 'eosio-cpp -abigen -o squeakr.wasm squeakr.cpp'
