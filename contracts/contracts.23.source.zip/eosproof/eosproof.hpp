/**
 *  @file
 *  @copyright defined in eos/LICENSE.txt
 */
#include <eosiolib/eosio.hpp>
#include <eosiolib/transaction.h>
#include <string>

using std::string;
using eosio::key256;
