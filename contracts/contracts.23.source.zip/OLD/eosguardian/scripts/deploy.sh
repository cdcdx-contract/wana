cleos set contract eosguradian1 eosguardian
cleos push action eosguardian1 setsettings '{"cap_total": "10.0000 EOS", "cap_tx": "2.0000 EOS", "duration": 1}' -p eosguardian1
