cleos get table eosguardian1 eosguardian1 settings
cleos get table eosguardian1 eosguardian1 txrecord
