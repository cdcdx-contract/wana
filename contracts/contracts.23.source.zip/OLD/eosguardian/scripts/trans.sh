cleos push action eosguardian1 safetransfer '{"to": "bp1", "quantity": "1.0000 EOS", "memo": "hello"}' -p eosguardian1@safeperm
