# trentLotteryContract
smart contract on EOS!
