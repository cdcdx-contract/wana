eosiocpp -o knights/knights.wast knights/knights.cpp
eosiocpp -g knights/knights.abi knights/knights.cpp

