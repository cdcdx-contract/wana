# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: pexpreturn

### Parameters
Input parameters:

* `from` (player name)
* `code` (target pet code)

### Intent
INTENT. The intent of the `{{ pexpreturn }}` action is to make the pet return the expedition. The pet will gain some magic water depending on grade and level and some random value.

### Term
TERM. This Contract expires at the conclusion of code execution.