# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: detach

### Parameters
Input parameters:

* `from` (player name)
* `id` (item id)

### Intent
INTENT. The intent of the `{{ detach }}` action is to detach item from the knight. When you detach the item, the stat of the knight changes.

### Term
TERM. This Contract expires at the conclusion of code execution.