# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: craft2

### Parameters
Input parameters:

* `from` (player name)
* `code` (target item id)
* `mat_ids` (material ids for item)
* `block` (last block)
* `checksum` (checksum field to prevent bots)

### Intent
INTENT. The intent of the `{{ craft }}` action is to craft item. The materials for item will be removed. The stat of the generated item is randomly given.

### Term
TERM. This Contract expires at the conclusion of code execution.