#pragma once

struct knight_stats {
    int attack;
    int defense;
    int hp;
    int luck;
    int drop_rate;
    int nature_drop_rate;
    int steel_drop_rate;
    int bone_drop_rate;
    int skin_drop_rate;
    int mineral_drop_rate;
};
