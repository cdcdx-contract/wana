struct transfer_action {
    name from;
    std::string action;
    std::string param;
    uint32_t type;
    name seller;
    asset quantity;
    uint32_t block;
    uint32_t checksum;
};