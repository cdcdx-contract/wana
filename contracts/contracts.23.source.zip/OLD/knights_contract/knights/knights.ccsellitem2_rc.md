# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: ccsellitem2

### Parameters
Input parameters:

* `from` (player name)
* `id` (item id to cancel selling)
* `block` (last block)
* `checksum` (checksum field to prevent bots)

### Intent
INTENT. The intent of the `{{ ccsellitem }}` action is to remove a item on the market. 

### Term
TERM. This Contract expires at the conclusion of code execution.