# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: lvupknight

### Parameters
Input parameters:

* `from` (player name)
* `type` (knight type)

### Intent
INTENT. The intent of the `{{ lvupknight }}` action is to make level up the knight. Level-up is possible only when the knight has sufficient experience. Magic water will be consumed during level-up. 

### Term
TERM. This Contract expires at the conclusion of code execution.
