# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: itemmerge

### Parameters
Input parameters:

* `from` (player name)
* `id` (target item id)
* `ingredient` (ingredient item ids)

### Intent
INTENT. The intent of the `{{ itemmerge }}` action is to merge items. The ingredient items will be removed and merged to target item. You can upgrade target item if that has enough ingredient.

### Term
TERM. This Contract expires at the conclusion of code execution.