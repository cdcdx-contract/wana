# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: petlvup

### Parameters
Input parameters:

* `from` (player name)
* `code` (target pet code)

### Intent
INTENT. The intent of the `{{ petlvup }}` action is to level up the pet. There must be sufficient cards in the target. It consumes magic water.

### Term
TERM. This Contract expires at the conclusion of code execution.