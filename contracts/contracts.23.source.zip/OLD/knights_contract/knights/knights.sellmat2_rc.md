# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: sellmat2

### Parameters
Input parameters:

* `from` (player name)
* `id` (material id to sell)
* `price` (material price)
* `block` (last block)
* `checksum` (checksum field to prevent bots)

### Intent
INTENT. The intent of the `{{ sellmat }}` action is to register a material to the market. Another players can buy registered materials on the market.

### Term
TERM. This Contract expires at the conclusion of code execution.