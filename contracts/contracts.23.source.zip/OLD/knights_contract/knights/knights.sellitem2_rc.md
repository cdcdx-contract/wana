# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: sellitem2

### Parameters
Input parameters:

* `from` (player name)
* `id` (item id to sell)
* `price` (item price)
* `block` (last block)
* `checksum` (checksum field to prevent bots)

### Intent
INTENT. The intent of the `{{ sellitem }}` action is to register a item to the market. Another players can buy registered items on the market.

### Term
TERM. This Contract expires at the conclusion of code execution.