# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: signup

### Parameters
Input parameters:

* `from` (player name)

### Intent
INTENT. The intent of the `{{ signup }}` action is to register account as a game player. This contract pay all the RAM for the game. This action can only be called once.

### Term
TERM. This Contract expires at the conclusion of code execution.
