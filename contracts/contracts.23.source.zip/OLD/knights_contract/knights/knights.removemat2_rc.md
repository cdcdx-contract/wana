# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: removemat2

### Parameters
Input parameters:

* `from` (player name)
* `mat_ids` (material ids to remove)
* `block` (last block)
* `checksum` (checksum field to prevent bots)

### Intent
INTENT. The intent of the `{{ removemat }}` action is to remove materials. Removed material will be changed to magic water.

### Term
TERM. This Contract expires at the conclusion of code execution.