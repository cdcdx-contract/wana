# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: ccsellmat2

### Parameters
Input parameters:

* `from` (player name)
* `id` (material id to cancel selling)
* `block` (last block)
* `checksum` (checksum field to prevent bots)

### Intent
INTENT. The intent of the `{{ ccsellmat }}` action is to remove a material on the market. 

### Term
TERM. This Contract expires at the conclusion of code execution.