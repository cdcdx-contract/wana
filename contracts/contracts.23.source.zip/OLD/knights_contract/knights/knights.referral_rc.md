# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: referral

### Parameters
Input parameters:

* `from` (player name)
* `to` (referral target player name)

### Intent
INTENT. The intent of the `{{ referral }}` action is to give referral bonus to from and to players. Both receive a bonus. But there is a limit to the number of bonuses. 

### Term
TERM. This Contract expires at the conclusion of code execution.