# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: equip

### Parameters
Input parameters:

* `from` (player name)
* `knight` (knight type)
* `id` (item id)

### Intent
INTENT. The intent of the `{{ equip }}` action is to equip item to the knight. When you quip the item, the stat of the knight changes.

### Term
TERM. This Contract expires at the conclusion of code execution.