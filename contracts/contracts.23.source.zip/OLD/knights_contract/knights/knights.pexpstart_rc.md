# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: pexpstart

### Parameters
Input parameters:

* `from` (player name)
* `code` (target pet code)

### Intent
INTENT. The intent of the `{{ pexpstart }}` action is to make the pet leave the expedition. The pet will gain some magic water depending on grade and level.

### Term
TERM. This Contract expires at the conclusion of code execution.