# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: itemlvup

### Parameters
Input parameters:

* `from` (player name)
* `id` (target item id)

### Intent
INTENT. The intent of the `{{ itemlvup }}` action is to level up the item. There must be sufficient ingredient in the target item. It consumes magic water.

### Term
TERM. This Contract expires at the conclusion of code execution.