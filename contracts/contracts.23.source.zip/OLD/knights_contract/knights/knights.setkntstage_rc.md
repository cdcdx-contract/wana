# CONTRACT FOR EOS KNIGHTS

## ACTION NAME: setkntstage

### Parameters
Input parameters:

* `from` (player name)
* `stage` (stage number where to play)

### Intent
INTENT. The intent of the `{{ setkntstage }}` action is to select stage where to play. The drop rate of the material changes depending on the stage.

### Term
TERM. This Contract expires at the conclusion of code execution.
