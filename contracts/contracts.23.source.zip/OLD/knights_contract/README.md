# EOS KNIGHTS!
<img src="http://eosknights.io/img/app.png" alt="Drawing" width="465" height="461"/>
EOS Knights is the first blockchain game on the EOS platform. All player actions are performed on smart contracts. Data is also stored securely in the EOS blockchain. Let's play EOS Knights together!

Hire a knight to protect the town from the goblins!
- Collect good materials.
- Craft items with collected materials.
- Equip items, the hero becomes stronger.
- Your knights can grow faster with a pet.


## About Bada Studio
Bada Studio build games that runs on EOS network as smart contract. EOS knights is a our first game. See more information here.
https://eosknights.io/

## Bug Bounty
- We have 'CONTRACT BUG BOUNTY' up to 200 EOS.
- If you found a bug or security issue on our contract, please contact us rather than attack.

### License
    Copyright (c) 2018-2019 Bada Studio.
    
    The MIT License
    
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
