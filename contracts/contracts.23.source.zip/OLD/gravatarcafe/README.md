gravatarcafe
-----------

This contract allows users to set a display name, image and telegram.

