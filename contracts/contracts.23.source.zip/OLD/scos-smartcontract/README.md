# scos-smartcontract
## Smart City On Steriods (SOS)
### DAPP based on eos.io for voting, crowfunding and verifying public projects by various private companies (vendors), keeping goverment bodies in loop for operational approvals (ex: need permission to build a public toilet using some goverment body).

### Data Model
![DATA MODEL](https://github.com/serganus/scos-smartcontract/blob/master/docs/datamodel.png)

### Workflow Model
![WORKFLOW](https://github.com/serganus/scos-smartcontract/blob/master/docs/workflow.png)