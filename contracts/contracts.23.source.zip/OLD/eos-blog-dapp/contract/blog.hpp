// Required generic eosio library provides print, type, math etc
#include <eosiolib/eosio.hpp>
#include <string>