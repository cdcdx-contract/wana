module.exports = {

    sysPrivKey: "5KQwrPbwdL6PhXujxW37FSSQZ1JiwsST4cqQzDeyXtP79zkvFD3",

    walletKey: "5JDw88vzbrjjKwUcawo43a4nUrAxTC9CAvBenQeGvamVDrk7K1M",
    executorKey: "5J3KnymNxGUTQGWUDKJYJGvdrXRWezqnFRFDrZbHL9BqXWqVTEK",

    executorOwner1: "5KTiC46AYt5nMWQV4jvjyjau4wJtQ5XeJc3ZLCEmcQxRxPFGVzG",
    executorOwner2: "5JG7ibULFm5t4Pqz75EtwxeWPRCTXMqsaEdYXhKhE4pyw3iF5gE",
    executorOwner3: "5KPMB9eu3uLRwWtgnAx5Fps2pxuRby259Pw4tcRtdrvVUACVdv7",

    cfoKey: "5Hy6fgqpDaczdH82wMK3BTKf7aktg3vj9qFdem35FL1bBykYro4",
    mktMgrKey: "5JzTMCC7u5eFvy1rBjQBkKjpkRNF5V9d3aTuUk6pXkB6bEGYvv5",
    hrMgrKey: "5JaekDL3XeCt3MjXvpUiRr1mowRVjCitXi4WKRKK5uDDPM4GN1d",

    recipientKey: "5JnYcuUZcxfzPenkLahzYvBVMrJXzPrV2Ms3zUzo2QVL9HNytfS",

    walletName: "wallet",
    executorName: "executor",
    cfoName: "cfo",
    mkgMgrName: "mktmgr",
    hrMgrName: "hrmgr",

    mktProgram1Name: "mktprogram1",
    mktProgram2Name: "mktprogram2",

    hrProgram1Name: "hrprogram1",
    hrProgram2Name: "hrprogram2",

    actionAddDepartment: "newdept",
    permissionAddDepartment: "newdept",

    actionToggleDepartment: "toggledept",
    permissionToggleDepartment: "tgldept",

    actionProcessApplication: "processapp",
    permissionProcessApplication: "processapp"
};