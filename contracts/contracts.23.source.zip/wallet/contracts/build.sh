mkdir build;
eosiocpp -o build/wallet.wast wallet.cpp;
eosiocpp -g build/wallet.abi wallet.cpp;