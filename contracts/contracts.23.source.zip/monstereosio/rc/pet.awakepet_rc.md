---
title: Wake Monster
summary: Wakes up a Monster in order to refill its energy
icon: https://monstereos.io/favicon.png#e6479a7f15b9f19775b09703a5973af41e6e6c0eefbe0c09b9f032a286248b74
---

## Wake Terms & Conditions

I, the owner of the pet {{pet_id}}, am waking this monster of
id {{pet_id}} to be make him awake and active and respond to
my interactions.

I understand that I cannot put it to sleep again in the
next 8 hours.

I understand that monsters actions are not reversible after the
{{$transaction.delay_sec}} seconds or other delay as configured
by my own permissions.

If this action fails to be irreversibly confirmed for technical issues
or failure, I agree that I need to attempt to submit this action again,
and also the subsequent interactions that I could possibly being submitted
in this interval.