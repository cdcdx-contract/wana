---
title: Change Birth Interv.
summary: Change Monsters creation interval time seconds
icon: https://monstereos.io/favicon.png#e6479a7f15b9f19775b09703a5973af41e6e6c0eefbe0c09b9f032a286248b74
---
In behalf of MonsterEOS and its community, and in the overall gameplay ecosystem, I allow the change of the creation monster tolerance interval to be {{new_interval}} seconds.
