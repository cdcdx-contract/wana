---
title: Transfer Monster
summary: Direct transfer a Monster
icon: https://monstereos.io/favicon.png#e6479a7f15b9f19775b09703a5973af41e6e6c0eefbe0c09b9f032a286248b74
---
I'm directly transferring the monster {{pet_id}} to the new owner {{new_owner}}. I understand that this action is irreversible and my monster RAM will be freed only if the new owner interacts with it.
