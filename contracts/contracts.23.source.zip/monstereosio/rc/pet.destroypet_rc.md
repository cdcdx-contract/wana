---
title: Destroy Monster
summary: Delete and destroy a Monster forever
icon: https://monstereos.io/favicon.png#e6479a7f15b9f19775b09703a5973af41e6e6c0eefbe0c09b9f032a286248b74
---

## Destroy Terms & Conditions

I, the owner of the pet {{pet_id}}, am destroying this monster
because I no longer have interest in taking care of it.

I understand that this action cannot be undone, the monster will
be cruelty destroyed and no longer be accessible or recreated by
anyone.

I understand that monsters actions are not reversible after the
{{$transaction.delay_sec}} seconds or other delay as configured
by my own permissions.

If this action fails to be irreversibly confirmed for technical issues
or failure, I agree that I need to attempt to submit this action again,
and also the subsequent interactions that I could possibly being submitted
in this interval.

