---
title: Create Monster
summary: Give birth to a Monster
icon: https://monstereos.io/favicon.png#e6479a7f15b9f19775b09703a5973af41e6e6c0eefbe0c09b9f032a286248b74
---

## Monster Creation Terms & Conditions

I, {{owner}}, authorize the creation of a random monster,
named as {{pet_name}}. I will love it and take care the best as I can.

I understand that I cannot create another monster in the next
60 (sixty) minute.

I understand that monsters actions are not reversible after the
{{$transaction.delay_sec}} seconds or other delay as configured
by my own permissions.

If this action fails to be irreversibly confirmed for technical issues
or failure, I agree that I need to attempt to submit this action again,
and also the subsequent interactions that I could possibly being submitted
in this interval.
