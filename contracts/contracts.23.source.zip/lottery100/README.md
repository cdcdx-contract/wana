EOS smart contract gambling game

Join us with 0.1000 EOS!   
As soon as we have 10 participants,  
the winner will receive 1.0000 EOS.  
You could be the winner! (fee 1%)  

All this has been implemented using Smart Contracts and no one can tamper with the voting process.

account-name: lotteryxx1oo

amount : 0.1000 EOS, 1.0000 EOS, 10.0000 EOS, 100.0000 EOS

site : https://lottery100.io/

history: https://eosflare.io/account/lotteryxx1oo

2018-09-07 rule change : 100 -> 10 participants

contact : eoslot100@gmail.com
