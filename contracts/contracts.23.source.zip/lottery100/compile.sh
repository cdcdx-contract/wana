eosiocpp -o lottery100.wast lottery100.cpp
eosiocpp -g lottery100.abi lottery100.cpp
