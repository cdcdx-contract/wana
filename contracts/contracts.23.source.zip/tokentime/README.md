# EOS-Token-With-TimeLock
EOSIO Token With Time Lock

Admin can transfer token to user anytime but user can transfer only when user have unlocked that token after 24 hour of first transfer between admin to user.
